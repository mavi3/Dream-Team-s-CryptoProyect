<?php
/* Este archivo debe manejar la lógica de obtener los datos de todos los usuarios */
?>