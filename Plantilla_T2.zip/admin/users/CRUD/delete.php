<?php
/* Este archivo debe manejar la lógica de borrar un usuario (y los registros relacionados) como admin */
?>