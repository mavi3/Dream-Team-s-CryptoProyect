<?php
/* Este archivo debe manejar la lógica de obtener los datos de un determinado usuario */
?>