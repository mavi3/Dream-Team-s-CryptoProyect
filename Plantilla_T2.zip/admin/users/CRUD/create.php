<?php
/* Este archivo debe manejar la lógica para crear un usuario como admin */
?>