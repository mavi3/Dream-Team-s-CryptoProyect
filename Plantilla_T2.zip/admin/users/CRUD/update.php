<?php
/* Este archivo debe manejar la lógica de actualizar los datos de un usuario como admin */
?>