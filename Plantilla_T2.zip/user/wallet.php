<?php
/* Este archivo debe manejar la lógica para obtener la información de la billetera */
?>