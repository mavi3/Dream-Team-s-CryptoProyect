<?php 
/* Este archivo debe manejar la lógica de iniciar sesión */
?>