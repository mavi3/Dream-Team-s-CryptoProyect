<?php
/* Este archivo debe manejar la lógica de cerrar una sesión */
?>